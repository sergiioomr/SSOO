// compilar : g++ -std=c++23 -o copycmp copy_cmp.cpp
#include <iostream>
#include <atomic>
#include <signal.h>
#include <cstdlib>
#include <sys/stat.h>
#include <sys/wait.h>
#include <cstring>
#include <expected>
#include <unistd.h>
#include <fcntl.h>
#include <climits>
#include <system_error>

std::atomic<bool> quit_requested = false;
void signal_handler(int signum) {
    quit_requested = true;
}
std::string get_filename(std::string path) {
  auto pos = path.find_last_of('/');
  if (pos == std::string::npos) return path;
  else {
    return path.substr(pos + 1);
  }
}

struct ServerOptions {
  std::string archivo_origen;
  bool reference = false;

};
std::expected<void, std::system_error> copy(std::string src_path, std::string dest_path, int mode) {
  if ( mode == 0 ) { // copiar en archivo ya existente 
    int src_fd = open(src_path.c_str(), O_RDONLY);
      if (src_fd == -1) {
          return std::unexpected(std::system_error(errno, std::system_category()));
      }
      int dest_fd = open(dest_path.c_str(), O_WRONLY | O_CREAT | O_TRUNC , 0644);
      if (dest_fd == -1) {
          return std::unexpected(std::system_error(errno, std::system_category()));
      }
      char buf[256];
      ssize_t bytes_read;
      while( (bytes_read = read(src_fd, buf, 256)) > 0 ) { // mientras leamos mas de 0 bytes 
        uint8_t b = 42;
        uint8_t m = 128;
        uint8_t r = b^m;
        ssize_t bytes_written = write(dest_fd, buf, bytes_read);
        if (bytes_written != bytes_read) { // error en escritura
          close(src_fd); 
          close(dest_fd);
          std::unexpected(std::system_error(errno, std::system_category()));
        }
    }
    std::cout << "Archivo creado, finalizado programa\n";
    close(src_fd); 
    close(dest_fd);
  }
  else if (mode == 1) {
    int src_fd = open(src_path.c_str(), O_RDONLY);
    if (src_fd == -1) {
      return std::unexpected(std::system_error(errno, std::system_category()));
    }
    char buf[256];
    ssize_t bytes_read;
    while( (bytes_read = read(src_fd, buf, 256)) > 0 ) { // mientras leamos mas de 0 bytes 
        uint8_t b = 42;
        uint8_t m = 128;
        uint8_t r = b^m;
        ssize_t bytes_written = write(1, buf, bytes_read);
        if (bytes_written != bytes_read) { // error en escritura
          close(src_fd); 
          close(1);
          std::unexpected(std::system_error(errno, std::system_category()));
        }
    }
    close(src_fd); 
    close(1);
  }
   
    return {};
}
ServerOptions parse_arguments(int argc, char* argv[]) {
  ServerOptions options;
  int i = 1;
  while (i < argc) {
    if (i == 1) {
        options.archivo_origen = argv[i];
    }
    if (i == 2) {
        if ((argv[1]) == "&") {
            options.reference = true;
        }
    }
    i++;
  }
   return options;
}

int main(int argc, char* argv[]) {
  if (argc < 2) {
    std::cerr << "uso : " << argv[0] << " ruta_archivo_origen [&]\n";
    return EXIT_FAILURE;
  }
  ServerOptions options = parse_arguments(argc, argv);
  std::string src_path = options.archivo_origen;
  bool reference = options.reference;
  std::string home = getenv("HOME");
  std::string file_dest = home + "/copy_cmp/cmp.ref";
  std::string dest_dir = home + "/copy_cmp";

  struct stat st;
  int status_st = stat(src_path.c_str(), &st);
  // Comprobar existencia archivo origen
  if (status_st == -1) {
    std::cerr << "El archivo origen no existe" << std::endl;
    return EXIT_FAILURE;
  }
  if (S_ISREG(st.st_mode) == -1 ) {
    std::cerr << "El archivo origen no es regular" << std::endl;
    return EXIT_FAILURE;
  }
  struct stat st_2;
  if (stat(dest_dir.c_str(), &st_2) == -1) {
    std::cout << "El directorio destino no existe" << std::endl;
    return EXIT_FAILURE;
  }
  // señales control c terminacion asincrona
  struct sigaction sa;
  sa.sa_handler = signal_handler;
  sigemptyset(&sa.sa_mask);
  sa.sa_flags = 0;
  sigaction(SIGTERM, &sa, NULL);
  sigaction(SIGINT, &sa, NULL);

  // comprobar si existe cmp.ref
  if (stat(file_dest.c_str(), &st_2) == -1) { // no existe cmp.ref
    std::cout << "El archivo destino no existe" << std::endl; 
    std::cout << "Creando archivo...\n"; 
    copy(src_path, file_dest, 0);
    return EXIT_SUCCESS;
  }
  else { // existe cmp.ref
    reference = true;
    if (reference == false ) {
      std::cerr << "El archivo destino existe, por lo que tiene que añadir un & en la linea de comandos despues de la ruta de origen para activar el servidor";
      return EXIT_FAILURE;
    }
    // SIGUSR1
    sigset_t signal_set;
    sigemptyset(&signal_set);
    sigaddset(&signal_set, SIGUSR1);
    if (sigprocmask(SIG_BLOCK, &signal_set, NULL) == -1) {
    // Error al bloquear señal SIGUSR1
      std::cerr << "Error al bloquear señal SIGUSR1\n";
      return EXIT_FAILURE;
    }
    std::cout << "Servidor iniciado con pid (" << getpid() << ")\n";
    std::cout << "Esperando señal SIGUSR1\n";
    kill(getpid(), SIGUSR1); // EJEMPLO PARA PROBAR QUE SE INICIA con SIGUSR1
    while (!quit_requested) {
      siginfo_t signal_info;
      int result = sigwaitinfo(&signal_set, &signal_info);
      if (result == -1) {
       // Error esperado señal SIGUSR1
        break;
      }
      std::cout << "Señal SIGUSR1 recibida, iniciando...\n"; 
      int pipefd[2];
      int result_pipe = pipe(pipefd);
      if (result_pipe == -1) {
       // Error creando pipe
        std::cerr << "Error al crear pipe\n";
        return EXIT_FAILURE;
      }
      pid_t pid = fork();
      if (pid == 0) { // Codigo hijo
        close(pipefd[1]);
        dup2(pipefd[0], STDIN_FILENO);
        std::string cmd = "cmp";
        std::string std_out = "-";
        std::string ruta_ref = "~/copy_cmp/cmp.ref";
        execlp( ruta_ref.c_str(), std_out.c_str(), cmd.c_str(), cmd.c_str(), nullptr);
        std::exit(errno);

      }
    // codigo padre
      close(pipefd[0]);
      dup2(pipefd[1], STDOUT_FILENO);
      copy(src_path, file_dest, 1);
      // esperar hijo 
      close(pipefd[1]);
      int status;
      waitpid(pid, &status, 0);
      if (status == -1) {
          std::cerr << "Error en la terminacion del hijo";
          continue;
      }
      if (status == 0) {
          std::cout << "Comparación correcta\n";
          return EXIT_SUCCESS;
      }
    }
    
  }
  
  return EXIT_FAILURE;
}